// --- 1. MOCK DATA STORE (Simulating Database) ---
const DB = {
    scholarships: [
        { id: 1, name: "Tata Trust Medical Scholarship", provider: "Tata Trusts", amount: "₹50,000 / year", deadline: "2026-08-31", category: "Medical", income_limit: 0, gender: "All", state: "All India", education: "Undergraduate", tags: ["Medical"], desc: "Financial assistance for meritorious students." },
        { id: 2, name: "HDFC Badhte Kadam", provider: "HDFC Bank", amount: "₹30,000", deadline: "2026-09-15", category: "General", income_limit: 600000, gender: "All", state: "All India", education: "Class 12", tags: ["Need-Based"], desc: "Support for high-performing students from disadvantaged backgrounds." },
        { id: 3, name: "Adobe India Women-in-Tech", provider: "Adobe", amount: "₹2,50,000", deadline: "2026-10-05", category: "Engineering", income_limit: 0, gender: "Female", state: "All India", education: "Undergraduate", tags: ["Women Only"], desc: "Empowering next-gen women leaders in technology." },
        { id: 4, name: "Post-Metric SC Scholarship", provider: "Govt of India", amount: "Tuition Waiver", deadline: "2026-11-20", category: "SC/ST", income_limit: 250000, gender: "All", state: "All India", education: "Class 10", tags: ["Government"], desc: "Complete financial support for reserved categories." },
        { id: 5, name: "Vidyasaarathi MP Scholarship", provider: "NSDL", amount: "₹20,000", deadline: "2026-07-15", category: "General", income_limit: 500000, gender: "All", state: "Madhya Pradesh", education: "Class 12", tags: ["State"], desc: "For students residing in Madhya Pradesh." },
        { id: 6, name: "L'Oréal India For Young Women", provider: "L'Oréal", amount: "₹2,50,000", deadline: "2026-06-30", category: "Science", income_limit: 400000, gender: "Female", state: "All India", education: "Undergraduate", tags: ["Science"], desc: "Encouraging young women to pursue science." },
        { id: 7, name: "MahaDBT Minority Scholarship", provider: "Govt of Maharashtra", amount: "₹25,000", deadline: "2026-12-31", category: "OBC", income_limit: 800000, gender: "All", state: "Maharashtra", education: "Postgraduate", tags: ["State"], desc: "State government aid for minority communities." },
        { id: 8, name: "Kind Circle Scholarship", provider: "Buddy4Study", amount: "₹12,000", deadline: "2026-05-20", category: "General", income_limit: 400000, gender: "All", state: "All India", education: "Class 10", tags: ["School"], desc: "Merit-cum-means scholarship for school students." },
        { id: 9, name: "Keep India Smiling Foundation", provider: "Colgate", amount: "₹30,000", deadline: "2026-08-15", category: "General", income_limit: 500000, gender: "All", state: "All India", education: "Class 12", tags: ["General"], desc: "Foundational support for deserving individuals." },
        { id: 10, name: "Siemens Scholarship", provider: "Siemens", amount: "Full Tuition + Books", deadline: "2026-09-01", category: "Engineering", income_limit: 200000, gender: "All", state: "All India", education: "Undergraduate", tags: ["Engineering"], desc: "For first-year engineering students from low-income families." },
        { id: 11, name: "OakNorth STEM Scholarship", provider: "OakNorth", amount: "₹30,000", deadline: "2026-10-10", category: "Engineering", income_limit: 0, gender: "Female", state: "Haryana", education: "Undergraduate", tags: ["STEM"], desc: "For female students in Haryana pursuing STEM." },
        { id: 12, name: "Santoor Women's Scholarship", provider: "Wipro Consumer Care", amount: "₹24,000", deadline: "2026-09-15", category: "General", income_limit: 0, gender: "Female", state: "Karnataka", education: "Class 12", tags: ["Women"], desc: "For young women from Karnataka." },
        { id: 13, name: "LIC Golden Jubilee", provider: "LIC", amount: "₹20,000", deadline: "2026-12-01", category: "General", income_limit: 200000, gender: "All", state: "All India", education: "Class 12", tags: ["Insurance"], desc: "For economically weaker sections." },
        { id: 14, name: "AICTE Pragati Scholarship", provider: "AICTE", amount: "₹50,000", deadline: "2026-11-30", category: "Technical", income_limit: 800000, gender: "Female", state: "All India", education: "Undergraduate", tags: ["Govt"], desc: "For girl students in technical degree/diploma." },
        { id: 15, name: "PM Yasasvi Scheme (Top Class)", provider: "Govt of India", amount: "₹75,000", deadline: "2026-08-01", category: "OBC", income_limit: 250000, gender: "All", state: "All India", education: "Postgraduate", tags: ["Top Tier"], desc: "Top class education for OBC/EBC/DNT students." }
    ],
    exams: [
        { id: 101, name: "JEE Advanced", date: "2026-05-26", mode: "Computer Based", difficulty: "High", tags: ["Engineering"] },
        { id: 102, name: "NEET UG", date: "2026-05-05", mode: "Pen & Paper", difficulty: "High", tags: ["Medical"] },
        { id: 103, name: "UPSC CSE", date: "2026-06-16", mode: "Offline", difficulty: "Very High", tags: ["Civil Services"] },
        { id: 104, name: "CAT 2026", date: "2026-11-24", mode: "Computer Based", difficulty: "High", tags: ["Management"] },
        { id: 105, name: "GATE 2026", date: "2026-02-04", mode: "Computer Based", difficulty: "High", tags: ["Engineering"] },
        { id: 106, name: "CLAT 2026", date: "2026-12-03", mode: "Offline", difficulty: "Medium", tags: ["Law"] },
        { id: 107, name: "NDA (I) 2026", date: "2026-04-21", mode: "Offline", difficulty: "Medium", tags: ["Defense"] },
        { id: 108, name: "BITSAT 2026", date: "2026-05-20", mode: "Computer Based", difficulty: "Medium", tags: ["Engineering"] },
        { id: 109, name: "CUET UG", date: "2026-05-15", mode: "Computer Based", difficulty: "Medium", tags: ["University"] },
        { id: 110, name: "UGC NET", date: "2026-06-10", mode: "Computer Based", difficulty: "Medium", tags: ["Teaching"] }
    ]
};

// --- 2. CONFIGURATION & STATE ---
const State = {
    isParentMode: false,
    activeTab: 'scholarships',
    filters: {
        income: 0, // Default 0 (Show All)
        category: 'All',
        gender: 'All',
        state: 'All',
        education: 'All'
    },
    sortBy: 'relevance'
};

// --- 3. DOM ELEMENTS ---
const els = {
    grid: document.getElementById('scholarship-grid'),
    parentToggle: document.getElementById('parent-mode-toggle'),
    body: document.body,
    searchInput: document.getElementById('search-input'),
    tabBtns: document.querySelectorAll('.tab-btn'),
    chat: {
        window: document.getElementById('chat-window'),
        msgs: document.getElementById('chat-messages'),
        input: document.getElementById('chat-input')
    }
};

// --- 4. CORE FUNCTIONS ---

// Render Logic
function render() {
    els.grid.innerHTML = '';

    if (State.activeTab === 'scholarships') {
        let list = applyFilters(DB.scholarships);
        list = applySort(list);

        if (list.length === 0) {
            els.grid.innerHTML = `<div style="text-align:center; grid-column: 1/-1; padding: 40px;">No scholarships found. Try changing filters.</div>`;
            return;
        }
        list.forEach(createScholarshipCard);
    } else {
        DB.exams.forEach(createExamCard);
    }

    if (State.isParentMode) humanizeText();
}

function applyFilters(data) {
    return data.filter(item => {
        // Income Logic:
        // Item limit 0 = No Limit (Passes everyone)
        // User Limit X = "My family earns X". 
        // Logic: You qualify if (Item Limit == 0) OR (Item Limit >= User Income)
        // Example: Item limit 2L. User earns 1L. 2L >= 1L (TRUE -> Qualify)
        // Example: Item limit 2L. User earns 5L. 2L >= 5L (FALSE -> Disqualify)

        const incomePass = item.income_limit === 0 || item.income_limit >= State.filters.income;

        const catPass = State.filters.category === 'All' || item.category.includes(State.filters.category);
        const genderPass = State.filters.gender === 'All' || item.gender === 'All' || item.gender === State.filters.gender;
        const statePass = State.filters.state === 'All' || item.state === 'All India' || item.state === State.filters.state;

        // Education Logic
        const eduPass = State.filters.education === 'All' || (item.education && item.education === State.filters.education);

        return incomePass && catPass && genderPass && statePass && eduPass;
    });
}

function applySort(data) {
    const d = [...data]; // Copy
    if (State.sortBy === 'amount-high') {
        return d.sort((a, b) => {
            const getVal = (str) => parseInt(str.replace(/[^0-9]/g, '')) || 0;
            return getVal(b.amount) - getVal(a.amount);
        });
    } else if (State.sortBy === 'deadline') {
        return d.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
    }
    return d; // relevance (default ID order)
}

function createScholarshipCard(item) {
    const card = document.createElement('div');
    card.className = 'scholarship-card glass-panel animate-pop';
    card.innerHTML = `
        <span class="tag">${item.tags[0]}</span>
        <h3 class="humanize" data-orig="${item.name}">${item.name}</h3>
        <p style="opacity: 0.7; font-size: 0.9em; margin: 5px 0;">${item.provider} | ${item.state}</p>
        
        <div style="margin: 15px 0; border-top: 1px solid var(--glass-border); padding-top: 10px;">
            <div class="row-between">
                <span class="humanize" data-orig="Amount">Amount</span>
                <strong style="color: var(--accent-color)">${item.amount}</strong>
            </div>
            <div class="row-between">
                <span class="humanize" data-orig="Deadline">Deadline</span>
                <strong>${item.deadline}</strong>
            </div>
             <div class="row-between">
                <span class="humanize" data-orig="For">For</span>
                <small>${item.category} / ${item.gender}</small>
            </div>
            <div class="row-between" style="font-size:0.85em; opacity:0.8">
                 <span class="humanize" data-orig="Edu">Edu</span>
                 <small>${item.education || 'Any'}</small>
            </div>
        </div>

        <button class="btn btn-primary" style="width:100%" onclick="alert('Proceeding to Application for ${item.id}...')">
            <span class="humanize" data-orig="View Details">View Details</span>
        </button>
    `;
    els.grid.appendChild(card);
}

function createExamCard(item) {
    const card = document.createElement('div');
    card.className = 'scholarship-card glass-panel animate-pop';
    card.style.borderLeft = "4px solid #f43f5e"; // Distinguish exams
    card.innerHTML = `
        <span class="tag" style="background:rgba(244, 63, 94, 0.2); color: #f43f5e">${item.tags[0]}</span>
        <h3 class="humanize" data-orig="${item.name}">${item.name}</h3>
        
        <div style="margin: 15px 0; border-top: 1px solid var(--glass-border); padding-top: 15px;">
            <div class="row-between">
                <span class="humanize" data-orig="Exam Date">Exam Date</span>
                <strong>${item.date}</strong>
            </div>
            <div class="row-between">
                <span class="humanize" data-orig="Mode">Mode</span>
                <span>${item.mode}</span>
            </div>
             <div class="row-between">
                <span class="humanize" data-orig="Difficulty">Difficulty</span>
                <span style="color:orange">${item.difficulty}</span>
            </div>
        </div>

        <button class="btn btn-primary" style="width:100%; filter: hue-rotate(45deg);">
            <span class="humanize" data-orig="Prepare Now">Prepare Now</span>
        </button>
    `;
    els.grid.appendChild(card);
}

// Parent Mode Logic
function toggleParentMode() {
    State.isParentMode = !State.isParentMode;
    if (State.isParentMode) {
        els.body.classList.add('parent-mode');
        humanizeText();
        updateToggleText("👨‍👩‍👧‍👦 Parent Mode: ON");
    } else {
        els.body.classList.remove('parent-mode');
        revertText();
        updateToggleText("👨‍👩‍👧‍👦 Parent Mode: OFF");
    }
}

function updateToggleText(text) {
    const label = els.parentToggle.querySelector('span');
    if (label) label.innerText = text;
}

// "Humanizer" Dictionary
const DICTIONARY = {
    "Amount": "Money You Get",
    "Deadline": "Last Date",
    "View Details": "Read More",
    "Scholarship": "Free Education Money",
    "Exam Date": "Test Day",
    "Prepare Now": "Start Reading",
    "Difficulty": "How Hard?",
    "Mode": "Location",
    "Find Your Perfect Scholarship": "Find Money for School",
    "Discover opportunities": "Look for help",
    "For": "Who?",
    "Edu": "Class Level"
};

function humanizeText() {
    document.querySelectorAll('.humanize').forEach(el => {
        const orig = el.getAttribute('data-orig') || el.innerText;
        el.setAttribute('data-orig', orig);
        if (DICTIONARY[orig]) el.innerText = DICTIONARY[orig];
    });
}
function revertText() {
    document.querySelectorAll('.humanize').forEach(el => {
        const orig = el.getAttribute('data-orig');
        if (orig) el.innerText = orig;
    });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    if (els.parentToggle) els.parentToggle.addEventListener('click', toggleParentMode);

    // Tab Switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            State.activeTab = e.target.dataset.tab; // 'scholarships' or 'exams'
            render();
        });
    });

    // Filter Listeners
    document.getElementById('filter-category').addEventListener('change', (e) => { State.filters.category = e.target.value; render(); });
    document.getElementById('filter-gender').addEventListener('change', (e) => { State.filters.gender = e.target.value; render(); });
    document.getElementById('filter-state').addEventListener('change', (e) => { State.filters.state = e.target.value; render(); });

    // New Filters
    const eduEl = document.getElementById('filter-education');
    if (eduEl) eduEl.addEventListener('change', (e) => { State.filters.education = e.target.value; render(); });

    const incEl = document.getElementById('filter-income');
    const incVal = document.getElementById('income-val');
    if (incEl) incEl.addEventListener('input', (e) => {
        State.filters.income = parseInt(e.target.value);
        if (incVal) incVal.innerText = `₹${(State.filters.income / 100000).toFixed(1)}L`;
        render();
    });

    // Sorting Listener
    const sortEl = document.getElementById('sort-select');
    if (sortEl) sortEl.addEventListener('change', (e) => { State.sortBy = e.target.value; render(); });

    // Initial Render
    render();
    checkLogin();
    console.log("ScholarEase Nexus Loaded.");
});


// --- 6. CHATBOT (Real Logic) ---
function toggleChat() {
    const win = els.chat.window;
    if (win) win.style.display = win.style.display === 'none' ? 'flex' : 'none';
}

function sendChat() {
    const text = els.chat.input.value.trim().toLowerCase();
    if (!text) return;

    // 1. User Message
    addMsg(els.chat.input.value, 'user');
    els.chat.input.value = '';

    // 2. Bot Logic
    let reply = "I'm still learning! Try searching above.";

    if (text.includes('hello') || text.includes('hi')) {
        reply = "Hello! I can help you find deadlines and amounts. Ask me 'When is the deadline for Tata?'";
    }
    else if (text.includes('deadline') || text.includes('when') || text.includes('date')) {
        const found = DB.scholarships.find(s => text.includes(s.name.toLowerCase().split(' ')[0].toLowerCase())); // fuzzy match first word
        if (found) reply = `The deadline for ${found.name} is ${found.deadline}.`;
        else reply = "Which scholarship? I couldn't find that name in my database.";
    }
    else if (text.includes('money') || text.includes('amount') || text.includes('how much')) {
        const found = DB.scholarships.find(s => text.includes(s.name.toLowerCase().split(' ')[0].toLowerCase()));
        if (found) reply = `You will receive ${found.amount}.`;
        else reply = "Which scholarship are you asking about?";
    }

    // 3. Bot Reply
    setTimeout(() => addMsg(reply, 'bot'), 400);
}

function addMsg(text, type) {
    const d = document.createElement('div');
    d.className = `msg ${type}`;
    d.innerText = text;
    d.style.marginBottom = '10px';
    d.style.padding = '8px 12px';
    d.style.borderRadius = '10px';
    d.style.maxWidth = '80%';

    if (type === 'user') {
        d.style.background = 'white';
        d.style.color = '#333';
        d.style.alignSelf = 'flex-end';
    } else {
        d.style.background = 'rgba(255,255,255,0.1)';
        d.style.alignSelf = 'flex-start';
    }

    els.chat.msgs.appendChild(d);
    els.chat.msgs.scrollTop = els.chat.msgs.scrollHeight;
}

// --- 7. AUTHENTICATION (Persistence) ---
function toggleLoginModal() {
    const modal = document.getElementById('login-modal');
    if (modal) modal.style.display = modal.style.display === 'none' ? 'flex' : 'none';
}

function handleLogin() {
    const name = document.getElementById('login-name').value;
    const email = document.getElementById('login-email').value;

    if (!name || !email) {
        alert("Please fill in all fields");
        return;
    }

    // Simulate API Call & Save to LocalStorage
    const user = { name, email, isLoggedIn: true };
    localStorage.setItem('currentUser', JSON.stringify(user));

    updateUIForLogin(user);
    toggleLoginModal();
}

function checkLogin() {
    const stored = localStorage.getItem('currentUser');
    if (stored) {
        const user = JSON.parse(stored);
        if (user.isLoggedIn) updateUIForLogin(user);
    }
}

function updateUIForLogin(user) {
    const btn = document.getElementById('login-btn');
    if (btn) {
        btn.innerHTML = `<i class='fas fa-user-circle'></i> Hi, ${user.name}`;
        btn.onclick = () => {
            if (confirm("Logout?")) {
                localStorage.removeItem('currentUser');
                location.reload();
            }
        };
    }
}
